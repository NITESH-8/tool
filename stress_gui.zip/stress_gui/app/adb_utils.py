"""
Android Debug Bridge (ADB) Utilities Module

This module provides a comprehensive interface for interacting with Android devices
through the Android Debug Bridge (ADB). It includes functions for device management,
command execution, file operations, and device communication.

Key Features:
- Device discovery and listing
- Command execution via ADB shell
- File push/pull operations
- Device connection management
- Root access handling
- Command batching with timing control

Dependencies:
- subprocess: For executing ADB commands
- shutil: For checking ADB availability

Author: Performance GUI Team
Version: 1.0
"""

from __future__ import annotations

import shutil
import subprocess
from typing import List, Optional, Tuple


def _run(cmd: List[str], timeout: int = 15) -> Tuple[int, str, str]:
	"""
	Execute a command and return the result with error handling.
	
	This is a low-level utility function that executes system commands
	and provides consistent error handling and return format. It's used
	by all ADB-related functions to execute commands safely.
	
	Args:
		cmd (List[str]): Command to execute as a list of arguments
		timeout (int): Maximum execution time in seconds (default: 15)
		
	Returns:
		Tuple[int, str, str]: (return_code, stdout, stderr)
			- return_code: Process exit code (0 = success)
			- stdout: Standard output as string
			- stderr: Standard error as string
			
	Error Handling:
		- TimeoutExpired: Returns code 124 with timeout message
		- FileNotFoundError: Returns code 127 with "not found" message
		- Other exceptions: Returns code 1 with exception message
		
	Example:
		>>> code, out, err = _run(["adb", "version"])
		>>> print(f"Exit code: {code}")
		Exit code: 0
	"""
	try:
		proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
		return proc.returncode, proc.stdout.strip(), proc.stderr.strip()
	except subprocess.TimeoutExpired as e:
		return 124, "", f"Timeout running: {' '.join(cmd)}"
	except FileNotFoundError:
		return 127, "", f"Executable not found: {cmd[0]}"
	except Exception as e:
		return 1, "", str(e)


def is_adb_available() -> bool:
	"""
	Check if ADB (Android Debug Bridge) is available on the system.
	
	This function checks if the ADB executable is available in the system PATH.
	It's used to determine if ADB functionality should be enabled in the UI.
	
	Returns:
		bool: True if ADB is available, False otherwise
		
	Example:
		>>> if is_adb_available():
		...     print("ADB is available")
		... else:
		...     print("ADB not found")
	"""
	return shutil.which("adb") is not None


def adb_version() -> str:
	"""
	Get the version information of the installed ADB.
	
	This function executes 'adb version' and returns the version string.
	It's useful for debugging and ensuring the correct ADB version is installed.
	
	Returns:
		str: ADB version string, or error message if ADB is not available
		
	Example:
		>>> version = adb_version()
		>>> print(f"ADB version: {version}")
		ADB version: Android Debug Bridge version 1.0.41
	"""
	code, out, err = _run(["adb", "version"]) if is_adb_available() else (127, "", "adb not found")
	return out or err


def list_devices() -> List[Tuple[str, str]]:
	"""
	List all connected Android devices.
	
	This function executes 'adb devices -l' to get a list of all connected
	Android devices with their serial numbers and status information.
	The -l flag provides additional model information when available.
	
	Returns:
		List[Tuple[str, str]]: List of (serial, label) tuples
			- serial: Device serial number
			- label: Human-readable device description with status
			
	Device States:
		- device: Connected and authorized
		- authorizing: Waiting for user authorization
		- unauthorized: Device not authorized
		- offline: Device not responding
		
	Example:
		>>> devices = list_devices()
		>>> for serial, label in devices:
		...     print(f"{serial}: {label}")
		emulator-5554: emulator-5554 (device) - Android SDK built for x86
	"""
	if not is_adb_available():
		return []
		
	code, out, err = _run(["adb", "devices", "-l"])  # -l gives model info when available
	if code != 0:
		return []
		
	devices: List[Tuple[str, str]] = []
	for line in out.splitlines():
		line = line.strip()
		if not line or line.startswith("List of devices"):
			continue
			
		parts = line.split()
		if len(parts) >= 2 and parts[1] in ("device", "authorizing", "unauthorized", "offline"):
			serial = parts[0]
			desc = " ".join(parts[2:]) if len(parts) > 2 else ""
			state = parts[1]
			label = f"{serial} ({state})" + (f" - {desc}" if desc else "")
			devices.append((serial, label))
			
	return devices


def shell(serial: Optional[str], command: str, timeout: int = 30) -> Tuple[int, str, str]:
	"""
	Execute a shell command on an Android device via ADB.
	
	This function executes a command in the shell of the specified Android device.
	It's the primary way to interact with Android devices for command execution.
	
	Args:
		serial (Optional[str]): Device serial number, or None for default device
		command (str): Shell command to execute
		timeout (int): Maximum execution time in seconds (default: 30)
		
	Returns:
		Tuple[int, str, str]: (return_code, stdout, stderr)
			- return_code: Command exit code (0 = success)
			- stdout: Command output
			- stderr: Command error output
			
	Example:
		>>> code, out, err = shell("emulator-5554", "ls /sdcard")
		>>> print(f"Files: {out}")
		Files: Download Documents Pictures
	"""
	if not is_adb_available():
		return 127, "", "adb not found"
		
	args = ["adb"]
	if serial:
		args += ["-s", serial]
	args += ["shell", command]
	return _run(args, timeout=timeout)


def push(serial: Optional[str], local_path: str, remote_path: str, timeout: int = 60) -> Tuple[int, str, str]:

	if not is_adb_available():
		return 127, "", "adb not found"
	args = ["adb"]
	if serial:
		args += ["-s", serial]
	args += ["push", local_path, remote_path]
	return _run(args, timeout=timeout)


def pull(serial: Optional[str], remote_path: str, local_path: str, timeout: int = 60) -> Tuple[int, str, str]:

	if not is_adb_available():
		return 127, "", "adb not found"
	args = ["adb"]
	if serial:
		args += ["-s", serial]
	args += ["pull", remote_path, local_path]
	return _run(args, timeout=timeout)


def ensure_root(serial: Optional[str], timeout: int = 20) -> Tuple[int, str, str]:

	if not is_adb_available():
		return 127, "", "adb not found"
	args = ["adb"]
	if serial:
		args += ["-s", serial]
	args += ["root"]
	return _run(args, timeout=timeout)


def wait_for_device(serial: Optional[str], timeout: int = 60) -> Tuple[int, str, str]:

	if not is_adb_available():
		return 127, "", "adb not found"
	args = ["adb"]
	if serial:
		args += ["-s", serial]
	args += ["wait-for-device"]
	return _run(args, timeout=timeout)


def send_commands(serial: Optional[str], commands: List[str], spacing_ms: int = 300) -> Tuple[int, str, str]:

	if not is_adb_available():
		return 127, "", "adb not found"
	stdout_all: List[str] = []
	stderr_all: List[str] = []
	for idx, cmd in enumerate(commands):
		code, out, err = shell(serial, cmd)
		stdout_all.append(out)
		stderr_all.append(err)
		if code != 0:
			return code, "\n".join(stdout_all).strip(), "\n".join(stderr_all).strip()
		if spacing_ms > 0 and idx < len(commands) - 1:
			import time
			time.sleep(max(0.01, spacing_ms / 1000.0))
	return 0, "\n".join(stdout_all).strip(), "\n".join(stderr_all).strip()


