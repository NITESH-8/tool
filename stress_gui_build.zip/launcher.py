#!/usr/bin/env python3
"""
Launcher script for StressGUI application.

This script sets up the proper module path and launches the application.
It's designed to work both in development and when packaged with PyInstaller.
"""

import sys
import os
from pathlib import Path

# Add the app directory to Python path
if getattr(sys, 'frozen', False):
    # Running as PyInstaller executable
    app_dir = Path(sys._MEIPASS) / "app"
else:
    # Running in development
    app_dir = Path(__file__).parent / "stress_gui" / "app"

if str(app_dir) not in sys.path:
    sys.path.insert(0, str(app_dir))

# Import and run the main application
from main import main

if __name__ == "__main__":
    main()
