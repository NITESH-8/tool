#!/usr/bin/env python3
"""
Build script for creating executable from the Performance GUI application.

This script uses PyInstaller to create a standalone executable that includes
all dependencies and can run on any Windows PC without requiring Python installation.

Usage:
    python build_exe.py

Output:
    - dist/StressGUI.exe (standalone executable)
    - build/ (temporary build files)
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def main():
    """Main build function."""
    print("Building StressGUI Executable...")
    print("=" * 50)
    
    # Get the project directory
    project_dir = Path(__file__).parent
    stress_gui_dir = project_dir / "stress_gui"
    app_dir = stress_gui_dir / "app"
    
    # Verify the main module exists
    main_py = app_dir / "main.py"
    if not main_py.exists():
        print("ERROR: main.py not found!")
        print(f"Expected: {main_py}")
        return False
    
    print(f"Found main module: {main_py}")
    
    # Clean previous builds
    print("\nCleaning previous builds...")
    for dir_name in ["build", "dist"]:
        dir_path = project_dir / dir_name
        if dir_path.exists():
            print(f"   Removing {dir_name}/")
            shutil.rmtree(dir_path)
    
    # PyInstaller command
    cmd = [
        "python", "-m", "PyInstaller",
        "--onefile",                    # Create single executable file
        "--windowed",                   # No console window (GUI app)
        "--name=StressGUI",             # Executable name
        "--distpath=dist",              # Output directory
        "--workpath=build",             # Temporary build directory
        "--specpath=.",                 # Spec file location
        
        # Add data files
        "--add-data=stress_gui/app;app",  # Include app directory
        
        # Hidden imports (PyInstaller might miss these)
        "--hidden-import=PySide6",
        "--hidden-import=PySide6.QtCore",
        "--hidden-import=PySide6.QtGui", 
        "--hidden-import=PySide6.QtWidgets",
        "--hidden-import=pyqtgraph",
        "--hidden-import=numpy",
        "--hidden-import=numpy.core",
        "--hidden-import=numpy.core._methods",
        "--hidden-import=numpy.lib",
        "--hidden-import=numpy.lib.format",
        "--hidden-import=serial",
        "--hidden-import=serial.tools",
        "--hidden-import=serial.tools.list_ports",
        
        # Optimize the build
        "--optimize=2",                 # Python optimization level
        "--strip",                      # Remove debug symbols
        
        # Exclude unnecessary modules to reduce size
        "--exclude-module=tkinter",
        "--exclude-module=matplotlib",
        "--exclude-module=pandas",
        "--exclude-module=scipy",
        "--exclude-module=IPython",
        "--exclude-module=jupyter",
        
        # Main module - use the launcher script
        "launcher.py"
    ]
    
    print(f"\nRunning PyInstaller...")
    print(f"Command: {' '.join(cmd)}")
    print("-" * 50)
    
    try:
        # Run PyInstaller
        result = subprocess.run(cmd, cwd=project_dir, check=True, 
                              capture_output=True, text=True)
        
        print("PyInstaller completed successfully!")
        print("\nBuild Output:")
        print(result.stdout)
        
        if result.stderr:
            print("\nWarnings/Info:")
            print(result.stderr)
        
    except subprocess.CalledProcessError as e:
        print(f"ERROR: PyInstaller failed with exit code {e.returncode}")
        print(f"Error output: {e.stderr}")
        return False
    except FileNotFoundError:
        print("ERROR: PyInstaller not found! Make sure it's installed and in PATH.")
        print("Try: pip install pyinstaller")
        return False
    
    # Check if executable was created
    exe_path = project_dir / "dist" / "StressGUI.exe"
    if exe_path.exists():
        size_mb = exe_path.stat().st_size / (1024 * 1024)
        print(f"\nSUCCESS! Executable created:")
        print(f"   Location: {exe_path}")
        print(f"   Size: {size_mb:.1f} MB")
        print(f"\nYou can now distribute this .exe file!")
        print(f"   No Python installation required on target PCs.")
        
        # Create a simple README for distribution
        readme_path = project_dir / "dist" / "README.txt"
        with open(readme_path, 'w') as f:
            f.write("""StressGUI - Performance Monitoring Application

This is a standalone executable that requires no installation.

SYSTEM REQUIREMENTS:
- Windows 10 or later
- For Android communication: ADB must be installed
- For UART communication: Appropriate COM port drivers

USAGE:
1. Double-click StressGUI.exe to run
2. No additional setup required

FEATURES:
- Real-time performance monitoring
- CPU, GPU, and DRAM stress testing
- Multi-protocol communication (UART, ADB, SSH, CMD)
- Data export (CSV, PNG)
- Live performance graphs

For support or questions, refer to the original project documentation.
""")
        
        print(f"   Created README.txt for distribution")
        return True
    else:
        print("ERROR: Executable not found after build!")
        return False

if __name__ == "__main__":
    success = main()
    if success:
        print("\nBuild completed successfully!")
        sys.exit(0)
    else:
        print("\nBuild failed!")
        sys.exit(1)
