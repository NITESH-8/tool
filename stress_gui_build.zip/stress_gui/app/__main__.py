#!/usr/bin/env python3
"""
Entry point for the StressGUI application when run as a module.

This file allows the application to be run with:
    python -m app.main
    python -m app

It ensures proper module path handling for both development and PyInstaller builds.
"""

import sys
import os
from pathlib import Path

# Add the app directory to Python path for absolute imports to work
app_dir = Path(__file__).parent
if str(app_dir) not in sys.path:
    sys.path.insert(0, str(app_dir))

# Import and run the main application
from main import main

if __name__ == "__main__":
    main()
