import time
import random

# File name
output_file = "stress_too_output.txt"

# Sample 1 (fixed content at the start)
sample1 = """[INFO] Detected CPU cores: 7
[CPU] Starting CPU loader with per-core Targets:
  Core 0: 60%
  Core 1: 80%
[INFO] Starting DRAM load with Target: 40%
[INFO] Starting GPU load with Target: 50%
[INFO] Baseline CPU usage: 24.9296%
[INFO] Baseline DRAM usage: 4.87443%
[INFO] Baseline GPU usage: 0%
[INFO] Total system memory: 27584 MB
[Monitor] CPU Usage (per core):
  cpu: 24.9556%
  cpu0: 61.7642%
  cpu1: 80.7642%
  cpu2: 36%
  cpu3: 19.7642%
  cpu4: 89.7642%
  cpu5: 61.7642%
  cpu6: 61.7642%
[Monitor] DRAM usage: 4.87443%
[Monitor] GPU usage: 0%
"""

# Function to generate sample2 with random values (0–90)
def generate_sample2():
    cpu_total = round(random.uniform(0, 90), 4)
    cores = [round(random.uniform(0, 90), 4) for _ in range(7)]
    dram_usage = round(random.uniform(0, 90), 5)
    gpu_usage = round(random.uniform(0, 90), 2)

    sample2 = "[Monitor] CPU Usage (per core):\n"
    sample2 += f"  cpu: {cpu_total}%\n"
    for i, val in enumerate(cores):
        sample2 += f"  cpu{i}: {val}%\n"
    sample2 += f"[Monitor] DRAM usage: {dram_usage}%\n"
    sample2 += f"[Monitor] GPU usage: {gpu_usage}%\n"
    return sample2


def main():
    # Write sample1 initially
    with open(output_file, "w") as f:
        f.write(sample1)

    # Append sample2 every 5 seconds for 60 seconds (12 iterations)
    for _ in range(30):
        time.sleep(2)
        with open(output_file, "a") as f:
            f.write(generate_sample2())

    # After 60 sec, append completion message
    with open(output_file, "a") as f:
        f.write("Sted\n")


if __name__ == "__main__":
    main()
